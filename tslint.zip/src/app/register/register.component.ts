import { Component, OnInit, Output, EventEmitter  } from '@angular/core';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  @Output() toggleEvent = new EventEmitter<boolean>();

  constructor() { }

  ngOnInit() {
  }

  toggle(val : boolean) {
    this.toggleEvent.emit(val);
  }

}
